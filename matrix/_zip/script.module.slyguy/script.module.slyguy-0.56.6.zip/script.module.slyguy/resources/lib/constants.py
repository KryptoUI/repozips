## NEWS ##
NEWS_URL = 'https://slyguy.uk/.repo/news.json.gz'
ADDONS_URL = 'https://slyguy.uk/.repo/addons.json.gz'
ADDONS_MD5 = 'https://slyguy.uk/.repo/addons.xml.md5'
NEWS_CHECK_TIME = 7200 #2 Hours
UPDATES_CHECK_TIME = 3600 #1 Hour
