import os,sys
import xbmc
import six
import xbmcplugin
import xbmcgui
import urllib3
import xbmcaddon

def check_version_update():
    # Get the current version number from the settings.xml file
    addon = xbmcaddon.Addon()
    current_version = addon.getSetting("version")
    
    # Send a GET request to the URL to get the latest version number
    http = urllib3.PoolManager()
    response = http.request('GET', "https://raw.githubusercontent.com/KryptoUI/repozips/master/matrix/_zip/plugin.video.midnight/version.txt")
    latest_version = response.data.decode().strip()
    
    # Compare the current version number with the latest version number
    if str(current_version) != str(latest_version):
        # Update the version number in the settings.xml file
        addon.setSetting("version", latest_version)
        
        # Send a GET request to the URL to get the changelog
        response = http.request('GET', "https://raw.githubusercontent.com/KryptoUI/repozips/master/matrix/_zip/plugin.video.midnight/changelog.txt")
        changelog = response.data.decode()
        
        # Create a dialog box to display the changelog
        dialog = xbmcgui.Dialog()
        dialog.textviewer("[COLORred]M[/COLOR][COLORwhite]idnight's[/COLOR] [COLORred]C[/COLOR][COLORwhite]hangelog[/COLOR]", changelog)

